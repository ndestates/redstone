-- MariaDB dump 10.19  Distrib 10.4.31-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.31-MariaDB-1:10.4.31+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `conference_speaker`
--

DROP TABLE IF EXISTS `conference_speaker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conference_speaker` (
  `conference_id` bigint(20) unsigned NOT NULL,
  `speaker_id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conference_speaker`
--

LOCK TABLES `conference_speaker` WRITE;
/*!40000 ALTER TABLE `conference_speaker` DISABLE KEYS */;
/*!40000 ALTER TABLE `conference_speaker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conference_talk`
--

DROP TABLE IF EXISTS `conference_talk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conference_talk` (
  `conference_id` bigint(20) unsigned NOT NULL,
  `talk_id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conference_talk`
--

LOCK TABLES `conference_talk` WRITE;
/*!40000 ALTER TABLE `conference_talk` DISABLE KEYS */;
/*!40000 ALTER TABLE `conference_talk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conferences`
--

DROP TABLE IF EXISTS `conferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conferences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `description` text NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `venue_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conferences`
--

LOCK TABLES `conferences` WRITE;
/*!40000 ALTER TABLE `conferences` DISABLE KEYS */;
INSERT INTO `conferences` VALUES (1,'Xzavier Fadel','Incidunt amet in et iste aut porro. Itaque consequatur molestiae illum aut. Perspiciatis quis sequi sint aspernatur similique. Enim vero delectus excepturi consequatur sint.','2024-09-12 14:44:22','2024-09-14 14:44:22',0,'draft','EU',NULL,'2023-12-12 14:44:22','2023-12-12 14:44:22'),(2,'Hardy Moen DVM','Consequatur sit hic rerum aliquam cum sint qui. Voluptatum magnam blanditiis corporis et et. At placeat dolores inventore voluptatem et. Aut cupiditate ea dolor voluptate dolor.','2024-09-12 14:44:22','2024-09-14 14:44:22',0,'published','Online',NULL,'2023-12-12 14:44:22','2023-12-12 14:44:22'),(3,'Lucy Hauck I','Eius dolores commodi et veniam omnis minus dignissimos aut. Ratione odio minus rerum nemo.','2024-09-12 14:44:22','2024-09-14 14:44:22',0,'draft','Online',NULL,'2023-12-12 14:44:22','2023-12-12 14:44:22'),(4,'Kara Von MD','Omnis ipsam voluptatum rerum incidunt. Aspernatur id omnis asperiores odio dolorem est aliquid officia.','2024-09-12 14:44:22','2024-09-14 14:44:22',0,'published','UK',NULL,'2023-12-12 14:44:22','2023-12-12 14:44:22'),(5,'Cory Cummerata','Omnis aut fugit voluptatem delectus. Et ipsam iure libero animi et. Eius dolores nihil voluptas consequuntur ut ipsam. In distinctio vero nihil sunt omnis nulla.','2024-09-12 14:44:22','2024-09-14 14:44:22',0,'archived','EU',NULL,'2023-12-12 14:44:22','2023-12-12 14:44:22');
/*!40000 ALTER TABLE `conferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `uuid` char(36) DEFAULT NULL,
  `collection_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `disk` varchar(255) NOT NULL,
  `conversions_disk` varchar(255) DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`manipulations`)),
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`custom_properties`)),
  `generated_conversions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`generated_conversions`)),
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`responsive_images`)),
  `order_column` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_order_column_index` (`order_column`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,'App\\Models\\Venue',11,'efe3adba-6124-4dc3-b1d2-43774e9cc40b','venue-images','AdobeStock_62569099','01HHF8PMM7M6RDS3RV8MSDFK53.jpg','image/jpeg','public','public',1959897,'[]','[]','[]','[]',1,'2023-12-12 15:00:38','2023-12-12 15:00:38');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_12_04_150330_create_conferences_table',1),(6,'2023_12_04_150331_create_venues_table',1),(7,'2023_12_04_150332_create_speakers_table',1),(8,'2023_12_04_150333_create_talks_table',1),(9,'2023_12_04_150334_create_conference_speaker_table',1),(10,'2023_12_04_150335_create_conference_talk_table',1),(11,'2023_12_12_134716_create_media_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `speakers`
--

DROP TABLE IF EXISTS `speakers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `speakers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `avatar` text DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `qualifications` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`qualifications`)),
  `bio` text DEFAULT NULL,
  `twitter_handle` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `speakers`
--

LOCK TABLES `speakers` WRITE;
/*!40000 ALTER TABLE `speakers` DISABLE KEYS */;
INSERT INTO `speakers` VALUES (1,'Savion Lindgren III',NULL,'sammie.osinski@example.org','[\"business-leader\",\"charisma\",\"twitter-influencer\",\"open-source\"]','Placeat modi praesentium atque. Esse praesentium quia maiores voluptatem vel et nam. Consequatur quis velit provident mollitia assumenda. Ab optio et dicta corrupti rerum expedita.','voluptas','2023-12-12 14:44:41','2023-12-12 14:44:41'),(2,'Fidel Murray V',NULL,'franco.watsica@example.com','[]','Veniam expedita delectus corporis voluptatem est et. Asperiores deserunt nemo et quam. Autem necessitatibus alias vitae.','quia','2023-12-12 14:44:41','2023-12-12 14:44:41'),(3,'Dr. Domenick Dickinson',NULL,'noemie.cronin@example.org','[]','Temporibus ad nam aut qui. Dolor qui rerum dolores animi. Consequatur qui temporibus quas veritatis alias vitae occaecati. Consequatur similique praesentium pariatur numquam.','inventore','2023-12-12 14:44:41','2023-12-12 14:44:41'),(4,'Prof. Javier Lindgren',NULL,'vivien05@example.com','[\"youtube-influencer\",\"humanitarian\",\"unique-perspective\"]','Numquam praesentium consectetur quo iure. Quibusdam et qui maxime. Non libero ut magnam quibusdam ullam ducimus.','nulla','2023-12-12 14:44:41','2023-12-12 14:44:41'),(5,'Dr. Jordon Schneider',NULL,'lind.jamie@example.net','[\"humanitarian\",\"youtube-influencer\",\"open-source\",\"first-time\",\"twitter-influencer\",\"hometown-hero\",\"laracasts-contributor\",\"charisma\",\"business-leader\",\"unique-perspective\"]','Quidem labore sapiente qui veniam. Doloremque odit labore et praesentium. Vitae eaque illo non aut. Animi sit dolores nihil impedit repudiandae ut sit.','ducimus','2023-12-12 14:44:41','2023-12-12 14:44:41'),(6,'Gabriella White',NULL,'malinda00@example.net','[]','Illo fugiat sit blanditiis ut. Qui illum et velit. Ea aut in non non voluptates magnam.','qui','2023-12-12 14:44:41','2023-12-12 14:44:41'),(7,'Amparo McCullough',NULL,'gloria.lockman@example.com','[\"hometown-hero\",\"youtube-influencer\"]','Rerum temporibus odio eos dolor. Est error deleniti quo aliquam temporibus quasi. Suscipit omnis unde sapiente.','dolorem','2023-12-12 14:44:41','2023-12-12 14:44:41'),(8,'Hallie Dare',NULL,'vincenza81@example.net','[]','Impedit suscipit eum deserunt enim quis. Aliquam laboriosam odit debitis saepe. Ut excepturi commodi temporibus eos. Autem aliquam harum rerum dolorem est quo in.','consequatur','2023-12-12 14:44:41','2023-12-12 14:44:41'),(9,'Pansy Hayes',NULL,'jessika.herman@example.com','[]','Aut ut et minus illo quod officiis at. Quidem iusto unde modi voluptas. Aliquam quis sit qui libero neque nesciunt officia. Et ea sint non. Nulla sed reiciendis pariatur perferendis velit tempora et.','qui','2023-12-12 14:44:41','2023-12-12 14:44:41'),(10,'Ms. Jermaine O\'Kon',NULL,'lilly35@example.com','[]','Earum quam qui dolorem repellat quibusdam. Repellat rerum velit quam omnis fugiat ex. Quae sint sunt delectus aspernatur. Assumenda et et maiores modi qui incidunt harum assumenda.','corrupti','2023-12-12 14:44:41','2023-12-12 14:44:41');
/*!40000 ALTER TABLE `speakers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `talks`
--

DROP TABLE IF EXISTS `talks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `talks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `abstract` text NOT NULL,
  `length` varchar(255) NOT NULL DEFAULT 'Normal - 30 Minutes',
  `status` varchar(255) NOT NULL DEFAULT 'Submitted',
  `new_talk` tinyint(1) NOT NULL DEFAULT 1,
  `speaker_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `talks`
--

LOCK TABLES `talks` WRITE;
/*!40000 ALTER TABLE `talks` DISABLE KEYS */;
INSERT INTO `talks` VALUES (1,'Officia eius est et reiciendis.','Quia ipsa quia quas reprehenderit natus. Qui id exercitationem sint veniam illo aut explicabo voluptas.','Normal - 30 Minutes','Approved',1,1,'2023-12-12 14:44:41','2023-12-12 14:44:56'),(2,'Ullam aut magni.','Eaque a est neque accusamus aut. Et voluptate dicta id at. Sit id quae ut et nihil ipsam. Explicabo distinctio doloribus voluptatum sit.','Normal - 30 Minutes','Submitted',1,2,'2023-12-12 14:44:41','2023-12-12 14:44:41'),(3,'Ex sed et cupiditate porro eius.','Sint aut minima harum nisi rem perferendis. Adipisci quaerat facere sed deserunt eum recusandae.','Normal - 30 Minutes','Approved',1,3,'2023-12-12 14:44:41','2023-12-12 14:45:02'),(4,'Reprehenderit qui totam qui.','Iusto quia ut qui itaque iste aut facilis. Molestias nam quia eaque cumque cupiditate cumque enim. Illo voluptas sed libero commodi. Recusandae molestias blanditiis aperiam asperiores ex.','Normal - 30 Minutes','Submitted',1,4,'2023-12-12 14:44:41','2023-12-12 14:44:41'),(5,'Maxime rerum consequuntur incidunt.','Et animi ullam eum aspernatur. Itaque error praesentium veritatis vitae est sit.','Normal - 30 Minutes','Submitted',1,5,'2023-12-12 14:44:41','2023-12-12 14:44:41'),(6,'Maiores tempore consequatur dolores repudiandae.','Tempore aut laboriosam fugit neque eligendi voluptas sequi. Culpa quasi esse numquam provident. Magnam error eum odit neque temporibus qui. Cupiditate architecto tempora totam.','Normal - 30 Minutes','Submitted',1,6,'2023-12-12 14:44:41','2023-12-12 14:44:41'),(7,'Aut dolor expedita quod sit.','Saepe consequatur ea sunt possimus hic aut. Saepe facere et vel suscipit. Laborum omnis sunt minima rerum. Cumque fugiat ratione sed ad modi iusto.','Normal - 30 Minutes','Submitted',1,7,'2023-12-12 14:44:41','2023-12-12 14:44:41'),(8,'Nemo fugiat iure harum aliquid qui.','Itaque vero sit quis magnam. Eius quis minus totam hic atque autem id. Saepe reprehenderit error a. Facilis voluptas nihil cum delectus iure sit. Deleniti ut eligendi soluta aut.','Normal - 30 Minutes','Submitted',1,8,'2023-12-12 14:44:41','2023-12-12 14:44:41'),(9,'Autem dolorem labore.','Harum enim maxime architecto nobis aut quas. Asperiores nulla nemo non omnis omnis. Possimus est iste aliquam nulla et.','Normal - 30 Minutes','Rejected',1,9,'2023-12-12 14:44:41','2023-12-12 14:45:35'),(10,'Aut adipisci sint.','Laboriosam et et at consequatur reiciendis ullam praesentium. Maiores quos quae et non beatae voluptatum. Sed sapiente error voluptates voluptatum veritatis tempore. Ratione aut et porro unde.','Normal - 30 Minutes','Submitted',1,10,'2023-12-12 14:44:41','2023-12-12 14:44:41');
/*!40000 ALTER TABLE `talks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Nick Dodsley','nick@ndestates.com','2023-12-11 08:54:52','$2y$12$iscQIQ6Bfi2sRXqmTQwqWevnJdce.FHCefpU5MfJKv52Ppuz5YQ6a','a0NLqKjOgI','2023-12-11 08:54:52','2023-12-11 08:54:52');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venues`
--

DROP TABLE IF EXISTS `venues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `venues` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `postal_code` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venues`
--

LOCK TABLES `venues` WRITE;
/*!40000 ALTER TABLE `venues` DISABLE KEYS */;
INSERT INTO `venues` VALUES (1,'Estel Cruickshank','Juniusborough','Korea','34235','AU','2023-12-12 14:42:49','2023-12-12 14:42:49'),(2,'Prof. Sebastian Christiansen DVM','Luciennebury','Nicaragua','31132-4075','India','2023-12-12 14:42:49','2023-12-12 14:42:49'),(3,'Prof. Tania Crona','Schmidthaven','Canada','02817','AU','2023-12-12 14:42:49','2023-12-12 14:42:49'),(4,'Mittie Kilback','Lockmanville','Kiribati','20858','Online','2023-12-12 14:42:49','2023-12-12 14:42:49'),(5,'Lorenzo Beatty','New Wendellbury','Palau','54982','Online','2023-12-12 14:42:49','2023-12-12 14:42:49'),(6,'Miss Christina Mertz II','Makaylamouth','Isle of Man','65772','Online','2023-12-12 14:43:13','2023-12-12 14:43:13'),(7,'Deshawn Grant','West Jettieberg','Colombia','56470-1233','India','2023-12-12 14:43:13','2023-12-12 14:43:13'),(8,'Adela Bechtelar','Emilieport','Saint Helena','03876-5974','US','2023-12-12 14:43:13','2023-12-12 14:43:13'),(9,'Prof. Dane Bergnaum','Schinnerton','Panama','21790-9619','EU','2023-12-12 14:43:13','2023-12-12 14:43:13'),(10,'Constance Stark','Creminburgh','Ecuador','22017-7722','EU','2023-12-12 14:43:13','2023-12-12 14:43:13'),(11,'Space Center','Miami Florida','United States','111111','US','2023-12-12 15:00:38','2023-12-12 15:00:38');
/*!40000 ALTER TABLE `venues` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-12 15:42:49
