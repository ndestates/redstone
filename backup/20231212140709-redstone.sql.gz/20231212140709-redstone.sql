-- MariaDB dump 10.19  Distrib 10.4.31-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.31-MariaDB-1:10.4.31+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `conference_speaker`
--

DROP TABLE IF EXISTS `conference_speaker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conference_speaker` (
  `conference_id` bigint(20) unsigned NOT NULL,
  `speaker_id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conference_speaker`
--

LOCK TABLES `conference_speaker` WRITE;
/*!40000 ALTER TABLE `conference_speaker` DISABLE KEYS */;
/*!40000 ALTER TABLE `conference_speaker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conference_talk`
--

DROP TABLE IF EXISTS `conference_talk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conference_talk` (
  `conference_id` bigint(20) unsigned NOT NULL,
  `talk_id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conference_talk`
--

LOCK TABLES `conference_talk` WRITE;
/*!40000 ALTER TABLE `conference_talk` DISABLE KEYS */;
/*!40000 ALTER TABLE `conference_talk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conferences`
--

DROP TABLE IF EXISTS `conferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conferences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `description` text NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `venue_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conferences`
--

LOCK TABLES `conferences` WRITE;
/*!40000 ALTER TABLE `conferences` DISABLE KEYS */;
INSERT INTO `conferences` VALUES (1,'Miss Joanie Bahringer DVM','Id quam in totam consequatur et labore nostrum. Non quia ipsum ea voluptatem consectetur dolores molestiae. Cupiditate voluptas aut harum impedit veritatis veritatis.','2024-09-12 14:03:57','2024-09-14 14:03:57',0,'draft','AU',NULL,'2023-12-12 14:03:57','2023-12-12 14:03:57'),(2,'Hadley Yundt','Occaecati minus et culpa. Aut quia repellendus maiores et consequatur qui expedita. Et soluta corporis quis voluptatibus.','2024-09-12 14:03:57','2024-09-14 14:03:57',0,'published','UK',NULL,'2023-12-12 14:03:57','2023-12-12 14:03:57'),(3,'Prof. Jerrell Gulgowski II','Molestias ipsam eius temporibus quas ipsam et voluptatem. Aut at omnis in doloribus dolor soluta ut. Magni iste molestiae iusto beatae ipsa illum cum dolorum. Quae et deleniti deleniti architecto.','2024-09-12 14:03:57','2024-09-14 14:03:57',0,'draft','UK',NULL,'2023-12-12 14:03:57','2023-12-12 14:03:57'),(4,'Keira Schmeler','Rerum numquam perspiciatis qui laudantium vero. Possimus culpa sed et expedita provident veritatis est.','2024-09-12 14:03:57','2024-09-14 14:03:57',0,'draft','US',NULL,'2023-12-12 14:03:57','2023-12-12 14:03:57'),(5,'Waldo Murray DVM','Dolor cupiditate earum quas et sit accusamus temporibus iste. Aut sint occaecati dolorem deleniti necessitatibus tempore. Odio aut aut ut blanditiis ut laborum.','2024-09-12 14:03:57','2024-09-14 14:03:57',0,'archived','US',NULL,'2023-12-12 14:03:57','2023-12-12 14:03:57');
/*!40000 ALTER TABLE `conferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `uuid` char(36) DEFAULT NULL,
  `collection_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `disk` varchar(255) NOT NULL,
  `conversions_disk` varchar(255) DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`manipulations`)),
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`custom_properties`)),
  `generated_conversions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`generated_conversions`)),
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`responsive_images`)),
  `order_column` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_order_column_index` (`order_column`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_12_04_150330_create_conferences_table',1),(6,'2023_12_04_150331_create_venues_table',1),(7,'2023_12_04_150332_create_speakers_table',1),(8,'2023_12_04_150333_create_talks_table',1),(9,'2023_12_04_150334_create_conference_speaker_table',1),(10,'2023_12_04_150335_create_conference_talk_table',1),(11,'2023_12_12_134716_create_media_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `speakers`
--

DROP TABLE IF EXISTS `speakers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `speakers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `avatar` text DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `qualifications` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`qualifications`)),
  `bio` text DEFAULT NULL,
  `twitter_handle` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `speakers`
--

LOCK TABLES `speakers` WRITE;
/*!40000 ALTER TABLE `speakers` DISABLE KEYS */;
INSERT INTO `speakers` VALUES (1,'Peter Smitham Sr.',NULL,'lfay@example.org','[\"open-source\",\"business-leader\",\"charisma\",\"laracasts-contributor\",\"twitter-influencer\",\"unique-perspective\"]','Aut laborum sint placeat libero omnis dicta voluptas. Velit sunt dolores corrupti. Qui adipisci rerum consequatur aut.','laboriosam','2023-12-12 13:55:55','2023-12-12 13:55:55'),(2,'Harmon Kutch',NULL,'stracke.vergie@example.org','[\"open-source\",\"first-time\",\"business-leader\",\"hometown-hero\",\"humanitarian\",\"twitter-influencer\",\"laracasts-contributor\",\"charisma\",\"youtube-influencer\"]','Sed blanditiis iste consequatur eveniet quod. Id qui esse nobis. Minima voluptatem maxime necessitatibus omnis.','non','2023-12-12 13:55:55','2023-12-12 13:55:55'),(3,'Oran Reichert',NULL,'neva.barrows@example.net','[\"laracasts-contributor\"]','Corporis sed nam quam autem. Est atque praesentium nostrum corporis quo nisi aliquid.','a','2023-12-12 13:55:55','2023-12-12 13:55:55'),(4,'Daphnee Schaefer',NULL,'mara.towne@example.com','[\"charisma\",\"youtube-influencer\",\"open-source\",\"laracasts-contributor\",\"twitter-influencer\",\"first-time\",\"humanitarian\"]','Quam et non numquam velit vel omnis. Quia perspiciatis voluptatem autem reiciendis. Voluptatem et ducimus et et possimus perferendis. Rerum maxime placeat quia.','hic','2023-12-12 13:55:55','2023-12-12 13:55:55'),(5,'Baby Will',NULL,'julius.kautzer@example.com','[\"twitter-influencer\",\"business-leader\",\"charisma\",\"unique-perspective\"]','Ut omnis exercitationem distinctio. Blanditiis sed quam quis nobis provident voluptatem. Ut ullam autem ducimus et velit sed sapiente ut. Quia ab dolor laborum veritatis.','molestiae','2023-12-12 13:55:55','2023-12-12 13:55:55'),(6,'Prof. Laurence Howell',NULL,'gerardo.hamill@example.com','[\"open-source\",\"humanitarian\",\"business-leader\"]','Et veritatis mollitia id quam ut assumenda. Nulla aliquid ea sit error architecto odio numquam odit. Cupiditate esse deleniti iusto et est debitis sunt.','neque','2023-12-12 13:55:55','2023-12-12 13:55:55'),(7,'Quinten Lockman',NULL,'jaron.aufderhar@example.net','[\"laracasts-contributor\",\"charisma\",\"humanitarian\"]','Blanditiis qui blanditiis illum voluptatem quis saepe impedit. Architecto ratione reprehenderit voluptates architecto quam. Aut commodi nihil fugiat nesciunt.','animi','2023-12-12 13:55:55','2023-12-12 13:55:55'),(8,'Antonetta Runte V',NULL,'daugherty.elta@example.org','[\"twitter-influencer\",\"open-source\",\"unique-perspective\",\"laracasts-contributor\",\"business-leader\"]','Qui qui deserunt quis. Totam dolores omnis repudiandae dolores officiis quo.','maxime','2023-12-12 13:55:55','2023-12-12 13:55:55'),(9,'Keely Bruen',NULL,'kaela.fadel@example.net','[\"charisma\",\"business-leader\",\"youtube-influencer\",\"open-source\",\"laracasts-contributor\",\"first-time\",\"unique-perspective\"]','Asperiores itaque totam voluptatem magnam sit et ducimus neque. Et ut nulla qui non consequatur eius. Voluptas nihil est eveniet neque.','enim','2023-12-12 13:55:55','2023-12-12 13:55:55'),(10,'Josie Jerde',NULL,'jacobi.abagail@example.net','[]','Odit ut doloribus esse non ut eligendi voluptatem. Fugit consequatur nihil a. Dolorem dolores ea aut. Saepe inventore vero dolorum numquam nihil voluptas.','aut','2023-12-12 13:55:55','2023-12-12 13:55:55'),(11,'Mr. Chelsey Jakubowski I',NULL,'osinski.alanis@example.net','[\"youtube-influencer\",\"open-source\",\"first-time\"]','Quae illo est est eum. Non aspernatur minima distinctio voluptatem. Exercitationem quia facilis quam commodi. Est quos architecto odio odio et quisquam est.','tempore','2023-12-12 14:04:30','2023-12-12 14:04:30'),(12,'Josie Fisher',NULL,'goodwin.sallie@example.net','[\"charisma\",\"unique-perspective\"]','At dolores eius temporibus aspernatur officia tempora est. Et velit temporibus quia inventore. Ut velit placeat enim a. Qui minima vero sed et ipsam.','eius','2023-12-12 14:04:30','2023-12-12 14:04:30'),(13,'Andrew Kohler',NULL,'bernhard.mariela@example.net','[\"youtube-influencer\",\"twitter-influencer\",\"charisma\",\"open-source\",\"first-time\"]','Repellendus qui similique velit et unde quo ex. Voluptas in assumenda eum cupiditate enim. Qui odit praesentium pariatur et voluptatem.','esse','2023-12-12 14:04:30','2023-12-12 14:04:30'),(14,'Thora Greenholt',NULL,'hayley.parker@example.org','[\"open-source\",\"twitter-influencer\",\"laracasts-contributor\",\"unique-perspective\",\"hometown-hero\",\"humanitarian\",\"business-leader\",\"charisma\"]','Aperiam impedit nihil non enim est rem. Qui ut qui alias eum aperiam.','sapiente','2023-12-12 14:04:30','2023-12-12 14:04:30'),(15,'Mr. Omari O\'Keefe IV',NULL,'hailee06@example.com','[\"open-source\",\"humanitarian\",\"charisma\",\"laracasts-contributor\"]','Ullam maiores tenetur odit accusamus fugit beatae cupiditate. Dolor laboriosam dolorem at quia rerum. Rem aliquid aliquam sit tempora.','fuga','2023-12-12 14:04:30','2023-12-12 14:04:30');
/*!40000 ALTER TABLE `speakers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `talks`
--

DROP TABLE IF EXISTS `talks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `talks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `abstract` text NOT NULL,
  `length` varchar(255) NOT NULL DEFAULT 'Normal - 30 Minutes',
  `status` varchar(255) NOT NULL DEFAULT 'Submitted',
  `new_talk` tinyint(1) NOT NULL DEFAULT 1,
  `speaker_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `talks`
--

LOCK TABLES `talks` WRITE;
/*!40000 ALTER TABLE `talks` DISABLE KEYS */;
INSERT INTO `talks` VALUES (1,'Natus autem ea libero asperiores.','Quia veritatis dolorem nesciunt sit tempore qui asperiores. Nihil labore vel eos vel. Rerum perferendis minus numquam tempora ad praesentium.','Normal - 30 Minutes','Submitted',1,1,'2023-12-12 13:55:55','2023-12-12 13:55:55'),(2,'Quia inventore ut quaerat.','Voluptates molestiae neque et rem. Non consequatur enim perspiciatis qui quos. Possimus quisquam vel qui ea nobis id ut.','Normal - 30 Minutes','Submitted',1,2,'2023-12-12 13:55:55','2023-12-12 13:55:55'),(3,'Velit quas consequatur quis veniam nobis.','Illum est dicta voluptatibus maiores rerum omnis quibusdam. Veritatis libero est magni quos soluta saepe quaerat sit. Quos iusto dolores similique aut.','Normal - 30 Minutes','Submitted',1,3,'2023-12-12 13:55:55','2023-12-12 13:55:55'),(4,'Explicabo velit in atque quo reprehenderit.','Totam odio culpa laboriosam quia eum voluptatibus ullam. Optio corrupti sit rerum libero cumque amet quasi. Voluptatem eum omnis voluptas et quam laborum.','Normal - 30 Minutes','Submitted',1,4,'2023-12-12 13:55:55','2023-12-12 13:55:55'),(5,'Cupiditate voluptas non quae maiores.','Illum ex laborum rerum aut sed. Alias non dignissimos minus veniam consequatur dolor et. Temporibus libero aliquam sint.','Normal - 30 Minutes','Submitted',1,5,'2023-12-12 13:55:55','2023-12-12 13:55:55'),(6,'Corporis nam repudiandae dolorem architecto voluptatibus.','Et provident exercitationem accusantium et molestias ut. Temporibus occaecati dicta praesentium et earum. Sit adipisci et vel voluptas sunt et. Distinctio veniam aut ut quas doloremque.','Normal - 30 Minutes','Submitted',1,6,'2023-12-12 13:55:55','2023-12-12 13:55:55'),(7,'Quisquam eius atque aut et aspernatur.','Laudantium quaerat quisquam porro totam molestias perferendis. Magnam a quo tenetur in exercitationem. Eius consequuntur architecto commodi in. Eum enim non est eum libero tempore corporis.','Normal - 30 Minutes','Submitted',1,7,'2023-12-12 13:55:55','2023-12-12 13:55:55'),(8,'Quisquam rerum ut tempora ullam.','Et enim id quia sed veniam animi. Perspiciatis officia praesentium reiciendis corrupti quam. Magni rerum et incidunt ea eum dolorem velit nulla. Sit quia id in voluptatem rem.','Normal - 30 Minutes','Submitted',1,8,'2023-12-12 13:55:55','2023-12-12 13:55:55'),(9,'Sit natus voluptatibus.','Ipsa enim magni velit totam ut omnis. Delectus natus voluptas voluptate et vel. Animi est qui alias atque adipisci quis.','Normal - 30 Minutes','Submitted',1,9,'2023-12-12 13:55:55','2023-12-12 13:55:55'),(10,'Est numquam omnis.','Quia repellat blanditiis quidem. Dolor blanditiis earum neque nostrum. Quia illum numquam tenetur aut cum. Iusto temporibus molestias hic aut voluptate eligendi labore omnis.','Normal - 30 Minutes','Submitted',1,10,'2023-12-12 13:55:55','2023-12-12 13:55:55');
/*!40000 ALTER TABLE `talks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Nick Dodsley','nick@ndestates.com','2023-12-11 08:54:52','$2y$12$iscQIQ6Bfi2sRXqmTQwqWevnJdce.FHCefpU5MfJKv52Ppuz5YQ6a','a0NLqKjOgI','2023-12-11 08:54:52','2023-12-11 08:54:52'),(2,'Maeve Ondricka','jaeden11@example.com','2023-12-12 14:04:14','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','wfR9urbuR6','2023-12-12 14:04:14','2023-12-12 14:04:14'),(3,'Laurianne Schamberger','ana13@example.com','2023-12-12 14:04:14','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','ICl8WRxMGi','2023-12-12 14:04:14','2023-12-12 14:04:14'),(4,'Giovanny Dooley Sr.','rchristiansen@example.net','2023-12-12 14:04:14','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','MLm9GWZSkg','2023-12-12 14:04:14','2023-12-12 14:04:14'),(5,'Amani Labadie','wuckert.amya@example.com','2023-12-12 14:04:14','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','hZ2Uoc0dFJ','2023-12-12 14:04:14','2023-12-12 14:04:14'),(6,'Mellie Beer','kadin23@example.net','2023-12-12 14:04:14','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','KhIrMqkoBK','2023-12-12 14:04:14','2023-12-12 14:04:14');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venues`
--

DROP TABLE IF EXISTS `venues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `venues` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `postal_code` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venues`
--

LOCK TABLES `venues` WRITE;
/*!40000 ALTER TABLE `venues` DISABLE KEYS */;
INSERT INTO `venues` VALUES (1,'Prof. Eda Muller','Samaraborough','Cape Verde','55105','EU','2023-12-12 13:55:31','2023-12-12 13:55:31'),(2,'Eulah Bartoletti I','Lake Devante','Trinidad and Tobago','76046-8686','EU','2023-12-12 13:55:31','2023-12-12 13:55:31'),(3,'Velma Wuckert','Lake Luz','Anguilla','22604-3050','EU','2023-12-12 13:55:31','2023-12-12 13:55:31'),(4,'Prof. Furman Herman Sr.','New Mariana','Ghana','19149','AU','2023-12-12 13:55:31','2023-12-12 13:55:31'),(5,'Prof. Rosanna Larson DDS','Urieltown','Afghanistan','57381-6773','India','2023-12-12 13:55:31','2023-12-12 13:55:31');
/*!40000 ALTER TABLE `venues` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-12 14:07:09
