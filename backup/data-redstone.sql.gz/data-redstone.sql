-- MariaDB dump 10.19  Distrib 10.4.31-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.31-MariaDB-1:10.4.31+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `conference_speaker`
--

DROP TABLE IF EXISTS `conference_speaker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conference_speaker` (
  `conference_id` bigint(20) unsigned NOT NULL,
  `speaker_id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conference_speaker`
--

LOCK TABLES `conference_speaker` WRITE;
/*!40000 ALTER TABLE `conference_speaker` DISABLE KEYS */;
/*!40000 ALTER TABLE `conference_speaker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conference_talk`
--

DROP TABLE IF EXISTS `conference_talk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conference_talk` (
  `conference_id` bigint(20) unsigned NOT NULL,
  `talk_id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conference_talk`
--

LOCK TABLES `conference_talk` WRITE;
/*!40000 ALTER TABLE `conference_talk` DISABLE KEYS */;
/*!40000 ALTER TABLE `conference_talk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conferences`
--

DROP TABLE IF EXISTS `conferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conferences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `description` text NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `venue_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conferences`
--

LOCK TABLES `conferences` WRITE;
/*!40000 ALTER TABLE `conferences` DISABLE KEYS */;
INSERT INTO `conferences` VALUES (1,'Laracon USA 2024','USA Conference','2023-12-21 00:00:00','2023-12-25 00:00:00',1,'published','US',5,'2023-12-09 16:37:35','2023-12-09 16:37:35'),(2,'Indian Conference','India conference','2023-12-19 18:55:00','2023-12-22 15:00:00',1,'published','India',3,'2023-12-09 17:25:59','2023-12-09 17:26:36');
/*!40000 ALTER TABLE `conferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_12_04_150330_create_conferences_table',1),(6,'2023_12_04_150331_create_venues_table',1),(7,'2023_12_04_150332_create_speakers_table',1),(8,'2023_12_04_150333_create_talks_table',1),(9,'2023_12_04_150334_create_conference_speaker_table',1),(10,'2023_12_04_150335_create_conference_talk_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `speakers`
--

DROP TABLE IF EXISTS `speakers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `speakers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `qualifications` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`qualifications`)),
  `bio` text NOT NULL,
  `twitter_handle` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `speakers`
--

LOCK TABLES `speakers` WRITE;
/*!40000 ALTER TABLE `speakers` DISABLE KEYS */;
INSERT INTO `speakers` VALUES (1,'Hertha Wuckert','xavier.yundt@example.net','[]','Excepturi modi sit quasi vitae maxime laborum aliquam. Id quo at cupiditate libero doloribus rerum dolores. Magni praesentium quis quaerat. Qui quia laboriosam illum et ullam facilis culpa.','et','2023-12-09 16:30:54','2023-12-09 16:30:54'),(2,'Mr. Braxton Littel','ntillman@example.org','[]','Harum quia ipsa et suscipit et enim harum ipsum. Voluptatibus at a ut et repellendus pariatur. Iure et architecto molestias in placeat. Ut asperiores reiciendis iste ab.','velit','2023-12-09 16:30:54','2023-12-09 16:30:54'),(3,'Tomasa Luettgen','fstracke@example.net','[\"business-leader\",\"first-time\",\"hometown-hero\"]','Eum voluptatem rerum ut quia vel. Non adipisci consequatur nostrum natus exercitationem provident ipsum. Nisi esse at eos sit magnam.','architecto','2023-12-09 16:30:54','2023-12-09 16:35:35'),(4,'Colby O\'Hara','wfunk@example.net','[]','Natus laudantium et occaecati praesentium voluptates expedita. Distinctio esse voluptatibus impedit velit ipsa.','necessitatibus','2023-12-09 16:30:54','2023-12-09 16:30:54'),(5,'Reta Stark','morissette.crystel@example.com','[]','Non eos voluptatem sit. Molestiae dolorem omnis mollitia ut rem saepe est. Iusto ipsa ipsam sint quibusdam.','id','2023-12-09 16:30:54','2023-12-09 16:30:54'),(6,'Leslie Friesen','jennyfer.bashirian@example.org','[]','Tempora earum est delectus sit ut qui. Voluptatum est quia est nostrum. Ut minus ut tempore molestias id.','adipisci','2023-12-09 16:30:54','2023-12-09 16:30:54'),(7,'Taurean Hodkiewicz','dmcglynn@example.com','[]','Quia iure officiis rerum eos nihil ipsam. Delectus cupiditate facere odit beatae et earum. Deserunt eum corporis omnis dicta. Voluptas vel et porro vel distinctio iure.','inventore','2023-12-09 16:30:54','2023-12-09 16:30:54'),(8,'Lavon Schinner PhD','wskiles@example.org','[]','Sed ab alias quisquam modi ab. Ullam quod nulla nulla et et. Cumque aliquam est molestiae incidunt possimus praesentium. Est illum omnis harum et corporis.','ut','2023-12-09 16:30:54','2023-12-09 16:30:54'),(9,'Sheridan Gislason','amayer@example.org','[]','Est quia maxime sit rerum laboriosam quia vel. Quia explicabo ipsa et. Rem autem blanditiis distinctio a. Eum sunt molestiae voluptatem dignissimos ut cupiditate nobis.','repellendus','2023-12-09 16:30:54','2023-12-09 16:30:54'),(10,'Frankie Wiza','jaren.boyer@example.net','[]','Consequatur incidunt aut reprehenderit eum ad. Voluptas dolorem deleniti est. Animi commodi sunt et in. Autem beatae natus quia qui eveniet numquam.','quis','2023-12-09 16:30:54','2023-12-09 16:30:54'),(11,'Prof. Marjory Cruickshank','kenneth.hahn@example.org','[]','Quasi quo voluptate reiciendis ducimus eum qui omnis. Perspiciatis quia neque debitis officia consequuntur recusandae.','odio','2023-12-09 16:30:54','2023-12-09 16:30:54'),(12,'Raleigh Prohaska','murphy.aaron@example.com','[]','Est autem ut voluptatum sed. Et culpa maiores quis distinctio. Unde aut est illum quidem non qui. Aperiam est omnis exercitationem qui eum.','ratione','2023-12-09 16:30:54','2023-12-09 16:30:54'),(13,'Kadin Nader III','fcorwin@example.com','[]','Odio doloremque qui enim vel consequatur doloremque vitae necessitatibus. Voluptas iusto odit aut qui animi nam. Ducimus nisi voluptatum ducimus est.','id','2023-12-09 16:30:54','2023-12-09 16:30:54'),(14,'Griffin Johns','grunolfsdottir@example.org','[]','Voluptates ducimus repudiandae totam ipsa qui et. Dolorem iusto expedita qui rerum dignissimos. Hic porro labore est sed dolorum quidem.','eius','2023-12-09 16:30:54','2023-12-09 16:30:54'),(15,'Alden Murazik','kirstin.gleason@example.net','[]','Quam sunt nam maxime quis nulla exercitationem. Et voluptatem voluptas voluptate sequi. Alias aut ipsa incidunt quia sunt velit. Fugiat vitae et aut quaerat iusto voluptatem totam.','sunt','2023-12-09 16:30:54','2023-12-09 16:30:54'),(16,'Sylvester Connelly','gregory.mante@example.net','[]','Officia itaque non libero et aliquam et. Sed labore consequatur aut aliquam iste occaecati. Quasi eos sunt nisi ipsam velit provident.','ea','2023-12-09 16:30:54','2023-12-09 16:30:54'),(17,'Prof. Easter Leuschke','browe@example.com','[]','Ad et voluptate beatae dolores quaerat dolorum mollitia id. Omnis impedit dolorem voluptatum rem. Sequi voluptatum sunt quia eveniet sunt.','ut','2023-12-09 16:30:54','2023-12-09 16:30:54'),(18,'Loma Barton','anya37@example.org','[]','Quia dignissimos tempora voluptatum. Dolor maiores qui quod recusandae odit voluptatum voluptate. Delectus veniam possimus suscipit error deleniti commodi.','et','2023-12-09 16:30:54','2023-12-09 16:30:54'),(19,'Miss Jessica Schroeder','uhowell@example.org','[]','Veritatis sit et exercitationem iste. Saepe facilis minus omnis in ut alias aut. Illo occaecati quo minus est iure nostrum voluptas.','eos','2023-12-09 16:30:54','2023-12-09 16:30:54'),(20,'Dr. Nedra Grimes Jr.','katelin35@example.com','[]','Eum delectus nisi quos et. Quaerat commodi voluptates doloremque et natus ut. Voluptates rerum praesentium officia ab aut est consequatur.','atque','2023-12-09 16:30:54','2023-12-09 16:30:54');
/*!40000 ALTER TABLE `speakers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `talks`
--

DROP TABLE IF EXISTS `talks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `talks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `abstract` text NOT NULL,
  `speaker_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `talks`
--

LOCK TABLES `talks` WRITE;
/*!40000 ALTER TABLE `talks` DISABLE KEYS */;
INSERT INTO `talks` VALUES (1,'Introduction to Laravel','Introduction',10,'2023-12-09 16:36:09','2023-12-09 16:36:09'),(2,'Laravel Plugins','Plugins today',15,'2023-12-09 16:36:33','2023-12-09 16:36:33'),(3,'The Benefits of Laravel','The benefits of Laravel',10,'2023-12-09 17:27:17','2023-12-09 17:27:17');
/*!40000 ALTER TABLE `talks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Nick Dodsley','nick@ndestates.com','2023-12-08 12:52:57','$2y$12$X6kDyxNBnQrnykjRW0f8GOWQ9PXSWUz/b.9zMMwkKWXa5U9zIjSNa','q6RYue68vb','2023-12-08 12:52:57','2023-12-08 12:52:57');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venues`
--

DROP TABLE IF EXISTS `venues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `venues` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `postal_code` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venues`
--

LOCK TABLES `venues` WRITE;
/*!40000 ALTER TABLE `venues` DISABLE KEYS */;
INSERT INTO `venues` VALUES (1,'Ricardo Hagenes','Justicehaven','Armenia','74617-2066','US','2023-12-09 16:32:54','2023-12-09 16:32:54'),(2,'Chasity Rolfson Stadium','Fadelfort','Germany','13534','EU','2023-12-09 16:32:54','2023-12-09 16:32:54'),(3,'Bombay Stadium','Mumbai','India','13498-3279','India','2023-12-09 16:32:54','2023-12-09 16:32:54'),(4,'Kaia Jones','New Fredton','Northern Mariana Islands','03212-0887','EU','2023-12-09 16:32:54','2023-12-09 16:32:54'),(5,'Prof. Luz Sawayn II Stadium','Fadelshire','New York','39631','US','2023-12-09 16:32:54','2023-12-09 16:32:54');
/*!40000 ALTER TABLE `venues` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-09 17:29:07
